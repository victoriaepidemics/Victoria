#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Nov  1 13:19:05 2020

@author: heiter
"""
# TODO: Setupexample() cargar los archivos de datos desde el paquete para facilitar un ejemplo

from configparsing.config import ModelConfig


from configparsing.config import ModelConfig;fullmodel=ModelConfig.fromfilename("SEIDconfig.hjson");fullmodel.writecode()


from configparsing.config import ModelConfig ; fullmodel = ModelConfig.fromfilename("AMAconfig.hjson");fullmodel.writecode()

from configparsing.config import ModelConfig ; fullmodel = ModelConfig.fromfilename("GRPconfig.hjson");fullmodel.writecode()
